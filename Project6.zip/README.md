# Project 6 - Distributed Key-Value Database
## High-Level Approach
## Challenges
### Getting started
- Read [Rutgers](https://people.cs.rutgers.edu/~pxk/417/notes/raft.html)
- Read [Raft Github](https://raft.github.io/slides/uiuc2016.pdf)
## Interesting Features
## Testing